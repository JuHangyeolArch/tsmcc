use std::ops::Range;
use std::fmt;
use std::error::Error;
use crate::compiler::ProducedBy;

use crate::compiler::SpanInfo;
use crate::compiler::CompileError;
use crate::compiler::ast::{
    Ast,
    AstNode,
    NodeID,
    AstNodeKind,
    AdditiveOpKind,
    MultiplicativeOpKind,
    StatementKind,
    FactorKind,
    BasicValueKind,
};
use crate::compiler::symtable::{
    FuncTable,
    FunctionInfo,
    ValueType,
    VarList,
    Variable,  
};

use crate::compiler::cs_analyzer::CsError;
use crate::compiler::cs_analyzer::scope_checker::assignexpr;
use crate::compiler::cs_analyzer::scope_checker::statement::stmtcomp;

use crate::compiler::cs_analyzer::scope_checker::ScopeStack;


pub fn sc_stmtif(
    ast: &Ast,
    func_table: &mut FuncTable,
    id: NodeID,
    entry: usize,
    ss: &mut ScopeStack
) -> Result<(),CsError> {

    let node = ast.get(id).unwrap();
    let lchild = node.get_lchild().unwrap();

    assignexpr::sc_assexpr(ast,func_table,lchild,entry,ss)?;
    
    let rchild = node.get_rchild().unwrap();

    ss.block_in();
    stmtcomp::sc_stmtcomp(ast,func_table,rchild,entry,ss)?;
    ss.pop();
    
    Ok(())
}
