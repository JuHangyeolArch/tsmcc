use crate::compiler::CompileError;


use crate::compiler::asm_table::{
AsmTable
};

use crate::compiler::assembly::{

    AssemblyInstruction,
    AssemblyLabel,
    AssemblyLine,
    AssemblyProgram,
    AssemblyValue,
    U12
    
};

use crate::compiler::machine_code::{
    MachineLine,
    MachineProgram,
    
};

mod first_pass;
mod second_pass;

#[derive(Debug, Clone, PartialEq)]
pub struct Assembler {
    program_counter: u16,

    first_ended: bool,
    second_ended: bool
}

impl Assembler {

    pub fn new() -> Self {
        Assembler {
            program_counter: 0,
            first_ended: false,
            second_ended: false,
        }
    }

    pub fn step(&self, asm_program: &AssemblyProgram, asm_table: &mut AsmTable, machine_code: &mut MachineProgram) -> Option<Result<(),CompilerError>>{
        if !self.first_ended {
            self.first_pass(asm_program, asm_table);
            return Some(Ok(()));            
        } else if  !self.second_ended {
            self.second_pass(asm_program,asm_table,machine_code); 
            return Some(Ok(()));
        }


        None

    }
    
}

