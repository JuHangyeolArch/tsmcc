use crate::compiler::ast::UnaryOpKind;
use crate::compiler::parser::Parser;
use crate::compiler::parser::ParseError;
use crate::compiler::ProducedBy;
use super::SpanInfo;
use super::CompileError;
use crate::compiler::token::{Token,TokenList,TokenType};
use crate::compiler::ast::{
    Ast,
    AstNode,
    NodeID,
    AstNodeKind,
    AdditiveOpKind,
    MultiplicativeOpKind,
    StatementKind,
    FactorKind,
    BasicValueKind,
};



impl Parser {

pub fn handle_assignexpr(
    &mut self,
    token_list: &TokenList,
    ast: &mut Ast ) -> Result<(), ParseError> {


        self.node_case(
            ast,
            token_list,
            |p, a, l| {

                let start: usize = p.get_cur_start(a);
                let end: usize;
                

                p.push_rchild(
                    a,
                    AstNodeKind::CondtionExpr,
                    start,
                    None
                );

                Ok(())
            },
            |p, a, l|{

                let start: usize = p
                    .get_lchild_end(a)
                    .unwrap();

                if ! matches!(l.get(start).unwrap().kind(), TokenType::Assign) {
                    p.set_cur_end(a,p.get_rchild_end(a).unwrap());
                    p.set_curnode(p.get_parent(a));
                    return Ok(());
                }
               
                p.push_rchild(
                    a,
                    AstNodeKind::AssignExpr,
                    start+1,
                    None                    
                );
                
                Ok(())
            },
            |p, a, l| {
                p.set_cur_end(a,p.get_rchild_end(a).unwrap());
                p.set_curnode(p.get_parent(a));
                Ok(())
            },
        )
    }
    
}
