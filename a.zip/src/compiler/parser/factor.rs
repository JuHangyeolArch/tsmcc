use crate::compiler::parser::Parser;
use crate::compiler::parser::ParseError;
use crate::compiler::ProducedBy;
use super::SpanInfo;
use super::CompileError;
use crate::compiler::token::{Token,TokenList,TokenType};
use crate::compiler::ast::{
    Ast,
    AstNode,
    NodeID,
    AstNodeKind,
    AdditiveOpKind,
    MultiplicativeOpKind,
    StatementKind,
    FactorKind,
    BasicValueKind,
};

mod faclit;
mod facvar;
mod facassign;
mod factypecast;
mod facpcall;

impl Parser {

    pub fn handle_factor(
        &mut self,
        token_list: &TokenList,
        ast: &mut Ast,
    ) -> Result<(), ParseError> {


        let start: usize = self.get_cur_start(ast);
        
        match self.case_factor(token_list,start) {
            FactorKind::Literal => {self.handle_faclit(token_list,ast)},
            FactorKind::Variable => {self.handle_facvar(token_list,ast)},
            FactorKind::ParenthAssign => {self.handle_facassign(token_list,ast)},
            FactorKind::TypeCast => {self.handle_factypecast(token_list,ast)},
            FactorKind::ProcedureCall => {self.handle_facpcall(token_list,ast)},
            FactorKind::Nil => {return Err(ParseError::InvalidSyntax(start))}
        }

        
    }

    pub fn case_factor(
        &mut self,
        token_list: &TokenList,
        start: usize
    ) -> FactorKind {

        match token_list
            .get(start)
            .unwrap()
            .kind() {
                TokenType::Number(_) => FactorKind::Literal,
                TokenType::Id(_) => {
                    if let TokenType::LParenth = token_list
                        .get(start+1)
                        .unwrap()
                        .kind() {
                            FactorKind::ProcedureCall
                        } else {
                            FactorKind::Variable
                        }
                },
                TokenType::LParenth => {
                    if let TokenType::Int = token_list
                        .get(start + 1)
                        .unwrap()
                        .kind() {
                            FactorKind::TypeCast
                        } else {
                            FactorKind::ParenthAssign
                        }
                },
                _ => FactorKind::Nil
            }
    }
    
}
